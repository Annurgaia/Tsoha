<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="content-type"
 content="text/html; charset=UTF-8">
  <title>Reseptitietokanta</title>
  <link href="tyyli.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="otsikko">Reseptitietokanta</div>
<div id="container">
<div id="navipalkki">
<?php include 'navi.html'; ?>
</div>
<div id="sisalto">Reseptipankissa voit hakea reseptejä ja eri tilanteisiin sopivia ateriakokonaisuuksia reseptien nimillä tai reseptissä esiintyvillä raaka-aineilla. Annamme myös juomasuosituksia eri ruokalajien kanssa nautittaviksi.
</br>
</br>
</br>
</div>
</div>
</body>
</html>

